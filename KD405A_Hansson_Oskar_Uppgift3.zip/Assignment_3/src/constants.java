
public class constants {

		/** constants that limits the values of the bikes crearted in main.java */
		public static final int MIN_SIZE = 8;
		public static final int MAX_SIZE = 28;
		public static final int MIN_PRICE = 0;
		public static final int MAX_PRICE = 30000;
		//public static final String[] bikeColors = new String[3];
		public static final String[] bikeColors= new String[] {"grön","röd","vit", "svart", "blå"};
		public static final int MAX_LENGTH = 30;
		
			
		
		


}
		
//myMethod(new String[] {"spades", "hearts"});

//myMethod({"spades", "hearts"}); //won't compile!

